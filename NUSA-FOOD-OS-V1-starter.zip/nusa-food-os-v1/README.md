# NUSA FOOD OS V1
## Sistem Intelijen Pengadaan dan Rantai Pasok Pangan

NUSA FOOD OS V1 adalah fondasi B2B untuk:
- katalog bahan pangan
- supplier dan stok
- permintaan penawaran (RFQ)
- quotation
- purchase order
- riwayat harga
- rekomendasi pembelian
- forecasting harga/permintaan
- ingestion data CSV/API
- audit dan monitoring

## Bahasa
Antarmuka, seed data, label API, dokumentasi, dan pesan bisnis menggunakan Bahasa Indonesia.

## Arsitektur
- Backend: Laravel 11/12-compatible
- Database: PostgreSQL + PostGIS
- Cache/Queue: Redis
- ML service: Python FastAPI
- Frontend: Next.js + TypeScript
- Reverse proxy: Nginx
- Container: Docker Compose

## Status starter
Paket ini adalah fondasi deployable dan skeleton implementasi V1. Modul inti sudah didefinisikan secara konsisten; integrasi sumber data eksternal dan model ML produksi perlu diisi dengan sumber/data nyata.

## Menjalankan
1. Salin `.env.example` menjadi `.env`
2. Isi rahasia yang diperlukan.
3. Jalankan:
   `docker compose up -d --build`
4. Jalankan migrasi/seed backend:
   `docker compose exec backend php artisan migrate --seed`
5. API:
   `http://localhost/api/v1`
6. Health:
   `http://localhost/api/v1/kesehatan`

## Produksi
- Ganti seluruh password/secret default.
- Gunakan HTTPS pada Nginx/Cloudflare.
- Jangan membuka PostgreSQL/Redis ke internet.
- Aktifkan backup PostgreSQL.
- Isi sumber data yang legal dan terverifikasi.
- Jalankan worker queue dan scheduler.

## Kredensial demo
Buat akun melalui endpoint pendaftaran atau ubah seeder sebelum produksi.
