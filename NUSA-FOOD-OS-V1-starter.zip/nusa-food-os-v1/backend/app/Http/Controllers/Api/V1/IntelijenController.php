<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Models\ObservasiHarga;
use App\Models\Rekomendasi;

class IntelijenController
{
    public function harga(Request $request)
    {
        $q = ObservasiHarga::query()->latest('diamati_pada');
        if ($request->filled('kota')) $q->where('kota', $request->string('kota'));
        if ($request->filled('varian_id')) $q->where('varian_produk_id', $request->string('varian_id'));
        return response()->json($q->paginate(50));
    }

    public function rekomendasi(Request $request)
    {
        return response()->json(
            Rekomendasi::where('organisasi_id', $request->user()?->organisasi_id)
                ->latest()->paginate(25)
        );
    }
}
