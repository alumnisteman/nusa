<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\JsonResponse;

class KesehatanController
{
    public function index(): JsonResponse
    {
        return response()->json([
            'status' => 'sehat',
            'layanan' => 'NUSA FOOD OS',
            'versi' => '1.0.0',
            'waktu' => now()->toIso8601String(),
        ]);
    }
}
