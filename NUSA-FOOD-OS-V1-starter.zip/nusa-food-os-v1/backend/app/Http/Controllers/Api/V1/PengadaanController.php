<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Rfq;

class PengadaanController
{
    public function daftarRfq(Request $request)
    {
        return response()->json(
            Rfq::where('organisasi_pembeli_id', $request->user()->organisasi_id)
               ->latest()->paginate(25)
        );
    }

    public function buatRfq(Request $request)
    {
        $data = $request->validate([
            'tanggal_dibutuhkan' => ['required','date'],
            'lokasi_pengiriman' => ['required','string','max:255'],
            'catatan' => ['nullable','string'],
        ]);

        $rfq = Rfq::create([
            'id' => Str::uuid(),
            'organisasi_pembeli_id' => $request->user()->organisasi_id,
            'nomor_rfq' => 'RFQ-'.now()->format('YmdHis').'-'.Str::upper(Str::random(4)),
            'status' => 'draft',
            ...$data,
        ]);

        return response()->json($rfq, 201);
    }
}
