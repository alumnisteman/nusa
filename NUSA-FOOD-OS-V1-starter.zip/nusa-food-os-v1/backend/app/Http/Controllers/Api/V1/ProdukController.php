<?php
namespace App\Http\Controllers\Api\V1;

use App\Models\Produk;
use Illuminate\Http\Request;

class ProdukController
{
    public function index(Request $request)
    {
        $q = Produk::query()->with('kategori');
        if ($request->filled('q')) {
            $q->where('nama', 'ilike', '%'.$request->string('q').'%');
        }
        return response()->json($q->paginate(25));
    }

    public function show(Produk $produk)
    {
        return response()->json($produk->load('kategori', 'varian'));
    }
}
