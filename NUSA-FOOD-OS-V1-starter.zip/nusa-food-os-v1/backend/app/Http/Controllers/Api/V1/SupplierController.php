<?php
namespace App\Http\Controllers\Api\V1;

use App\Models\Supplier;

class SupplierController
{
    public function index()
    {
        return response()->json(Supplier::query()->paginate(25));
    }

    public function show(Supplier $supplier)
    {
        return response()->json($supplier->load('organisasi'));
    }
}
