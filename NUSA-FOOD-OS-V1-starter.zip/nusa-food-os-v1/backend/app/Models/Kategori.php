<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Kategori extends Model
{
    use HasUuids;
    protected $table = 'kategori';
    protected $fillable = ['induk_id','nama','slug','status'];
}
