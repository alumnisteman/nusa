<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class ObservasiHarga extends Model
{
    protected $table = 'observasi_harga';
    protected $fillable = ['varian_produk_id','supplier_id','sumber_id','wilayah','kota','harga','mata_uang','satuan','diamati_pada','url_sumber','kepercayaan'];
    protected $casts = ['diamati_pada'=>'datetime','harga'=>'decimal:2','kepercayaan'=>'decimal:4'];
}
