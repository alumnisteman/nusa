<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Organisasi extends Model
{
    use HasUuids;
    protected $table = 'organisasi';
    protected $fillable = ['nama','jenis','nama_hukum','npwp','telepon','email','alamat','kota','provinsi','lintang','bujur','status'];
}
