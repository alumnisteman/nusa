<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Produk extends Model
{
    use HasUuids;
    protected $table = 'produk';
    protected $fillable = ['kategori_id','nama','slug','sku','deskripsi','status'];
    public function kategori(){ return $this->belongsTo(Kategori::class); }
    public function varian(){ return $this->hasMany(VarianProduk::class, 'produk_id'); }
}
