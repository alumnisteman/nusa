<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Rekomendasi extends Model
{
    use HasUuids;
    protected $table = 'rekomendasi';
    protected $fillable = ['organisasi_id','varian_produk_id','jenis','prioritas','alasan','perkiraan_penghematan','kepercayaan','berakhir_pada'];
}
