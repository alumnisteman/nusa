<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Rfq extends Model
{
    use HasUuids;
    protected $table = 'rfq';
    protected $fillable = ['organisasi_pembeli_id','nomor_rfq','status','tanggal_dibutuhkan','lokasi_pengiriman','catatan','berakhir_pada'];
}
