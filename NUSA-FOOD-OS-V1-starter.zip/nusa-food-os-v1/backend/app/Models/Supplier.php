<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Supplier extends Model
{
    use HasUuids;
    protected $table = 'supplier';
    protected $fillable = ['organisasi_id','kode_supplier','jenis','skor','terverifikasi','status'];
    public function organisasi(){ return $this->belongsTo(Organisasi::class); }
}
