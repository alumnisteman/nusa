<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class VarianProduk extends Model
{
    use HasUuids;
    protected $table = 'varian_produk';
    protected $fillable = ['produk_id','nama','sku','jumlah','satuan','kemasan','barcode','status'];
}
