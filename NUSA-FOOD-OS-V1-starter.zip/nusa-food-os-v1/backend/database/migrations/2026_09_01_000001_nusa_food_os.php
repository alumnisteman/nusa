<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void {
        DB::statement('CREATE EXTENSION IF NOT EXISTS postgis');
        DB::statement('CREATE EXTENSION IF NOT EXISTS pg_trgm');

        Schema::create('organisasi', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->string('nama'); $t->string('jenis',50);
            $t->string('nama_hukum')->nullable(); $t->string('npwp')->nullable();
            $t->string('telepon')->nullable(); $t->string('email')->nullable(); $t->text('alamat')->nullable();
            $t->string('kota')->nullable(); $t->string('provinsi')->nullable();
            $t->decimal('lintang',10,7)->nullable(); $t->decimal('bujur',10,7)->nullable();
            $t->string('status',30)->default('aktif'); $t->timestamps();
        });
        Schema::create('kategori', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->uuid('induk_id')->nullable(); $t->string('nama'); $t->string('slug')->unique();
            $t->string('status',30)->default('aktif'); $t->timestamps();
        });
        Schema::create('produk', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('kategori_id')->nullable()->constrained('kategori');
            $t->string('nama'); $t->string('slug')->unique(); $t->string('sku')->nullable(); $t->text('deskripsi')->nullable();
            $t->string('status',30)->default('aktif'); $t->timestamps();
        });
        Schema::create('varian_produk', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('produk_id')->constrained('produk')->cascadeOnDelete();
            $t->string('nama'); $t->string('sku')->unique(); $t->decimal('jumlah',12,3)->nullable(); $t->string('satuan',30);
            $t->string('kemasan')->nullable(); $t->string('barcode')->nullable(); $t->string('status',30)->default('aktif'); $t->timestamps();
        });
        Schema::create('alias_produk', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('produk_id')->constrained('produk')->cascadeOnDelete();
            $t->string('alias'); $t->string('sumber')->nullable(); $t->decimal('kepercayaan',5,4)->nullable(); $t->timestamps();
        });
        Schema::create('supplier', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('organisasi_id')->constrained('organisasi')->cascadeOnDelete();
            $t->string('kode_supplier')->unique(); $t->string('jenis',50)->nullable(); $t->decimal('skor',5,2)->default(0);
            $t->boolean('terverifikasi')->default(false); $t->string('status',30)->default('aktif'); $t->timestamps();
        });
        Schema::create('sumber_harga', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->string('nama'); $t->string('jenis',50); $t->text('url')->nullable();
            $t->string('wilayah')->nullable(); $t->decimal('skor_keandalan',5,4)->default(0); $t->boolean('aktif')->default(true); $t->timestamps();
        });
        Schema::create('observasi_harga', function(Blueprint $t){
            $t->bigIncrements('id'); $t->uuid('varian_produk_id'); $t->uuid('supplier_id')->nullable(); $t->uuid('sumber_id')->nullable();
            $t->string('wilayah')->nullable(); $t->string('kota')->nullable(); $t->decimal('harga',15,2);
            $t->char('mata_uang',3)->default('IDR'); $t->string('satuan',30); $t->timestamp('diamati_pada');
            $t->text('url_sumber')->nullable(); $t->decimal('kepercayaan',5,4)->nullable(); $t->timestamps();
            $t->index(['varian_produk_id','diamati_pada']); $t->index(['kota','diamati_pada']);
        });
        Schema::create('supplier_produk', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('supplier_id')->constrained('supplier')->cascadeOnDelete();
            $t->foreignUuid('varian_produk_id')->constrained('varian_produk')->cascadeOnDelete();
            $t->string('sku_supplier')->nullable(); $t->decimal('minimum_pesanan',15,3)->default(0);
            $t->integer('waktu_tunggu_hari')->default(0); $t->boolean('tersedia')->default(true); $t->timestamps();
            $t->unique(['supplier_id','varian_produk_id']);
        });
        Schema::create('rfq', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('organisasi_pembeli_id')->constrained('organisasi');
            $t->string('nomor_rfq')->unique(); $t->string('status',30)->default('draft'); $t->date('tanggal_dibutuhkan');
            $t->string('lokasi_pengiriman'); $t->text('catatan')->nullable(); $t->timestamp('berakhir_pada')->nullable(); $t->timestamps();
        });
        Schema::create('rfq_item', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('rfq_id')->constrained('rfq')->cascadeOnDelete();
            $t->foreignUuid('varian_produk_id')->constrained('varian_produk'); $t->decimal('jumlah',15,3); $t->string('satuan',30);
            $t->decimal('harga_target',15,2)->nullable(); $t->text('catatan')->nullable();
        });
        Schema::create('penawaran', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('rfq_id')->constrained('rfq')->cascadeOnDelete();
            $t->foreignUuid('supplier_id')->constrained('supplier'); $t->string('nomor_penawaran')->unique();
            $t->string('status',30)->default('diajukan'); $t->date('berlaku_sampai')->nullable();
            $t->integer('hari_pengiriman')->nullable(); $t->decimal('subtotal',15,2)->default(0);
            $t->decimal('biaya_pengiriman',15,2)->default(0); $t->decimal('total',15,2)->default(0); $t->timestamps();
        });
        Schema::create('penawaran_item', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('penawaran_id')->constrained('penawaran')->cascadeOnDelete();
            $t->foreignUuid('varian_produk_id')->constrained('varian_produk'); $t->decimal('jumlah',15,3);
            $t->decimal('harga_satuan',15,2); $t->decimal('subtotal',15,2);
        });
        Schema::create('pesanan_pembelian', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('organisasi_pembeli_id')->constrained('organisasi');
            $t->foreignUuid('supplier_id')->constrained('supplier'); $t->foreignUuid('penawaran_id')->nullable()->constrained('penawaran');
            $t->string('nomor_po')->unique(); $t->string('status',30)->default('draft'); $t->decimal('subtotal',15,2)->default(0);
            $t->decimal('biaya_pengiriman',15,2)->default(0); $t->decimal('total',15,2)->default(0);
            $t->timestamp('dipesan_pada')->nullable(); $t->date('perkiraan_tiba')->nullable(); $t->timestamps();
        });
        Schema::create('prediksi', function(Blueprint $t){
            $t->bigIncrements('id'); $t->uuid('varian_produk_id'); $t->string('wilayah'); $t->string('jenis',30);
            $t->integer('horizon_hari'); $t->decimal('nilai_prediksi',15,2); $t->decimal('batas_bawah',15,2)->nullable();
            $t->decimal('batas_atas',15,2)->nullable(); $t->decimal('kepercayaan',5,4)->nullable();
            $t->string('versi_model',50); $t->timestamp('dibuat_pada'); $t->timestamps();
        });
        Schema::create('rekomendasi', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('organisasi_id')->constrained('organisasi');
            $t->foreignUuid('varian_produk_id')->constrained('varian_produk'); $t->string('jenis',50);
            $t->string('prioritas',20); $t->text('alasan'); $t->decimal('perkiraan_penghematan',15,2)->nullable();
            $t->decimal('kepercayaan',5,4)->nullable(); $t->timestamp('berakhir_pada')->nullable(); $t->timestamps();
        });
        Schema::create('log_audit', function(Blueprint $t){
            $t->bigIncrements('id'); $t->uuid('user_id')->nullable(); $t->uuid('organisasi_id')->nullable();
            $t->string('aksi',100); $t->string('entitas',100)->nullable(); $t->uuid('entitas_id')->nullable();
            $t->jsonb('data_lama')->nullable(); $t->jsonb('data_baru')->nullable(); $t->ipAddress('alamat_ip')->nullable();
            $t->text('user_agent')->nullable(); $t->timestamp('dibuat_pada')->useCurrent();
        });
        Schema::create('sumber_data', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->string('nama'); $t->string('jenis',50); $t->text('url')->nullable();
            $t->string('wilayah')->nullable(); $t->decimal('skor_keandalan',5,4)->default(0); $t->boolean('aktif')->default(true); $t->timestamps();
        });
        Schema::create('pekerjaan_ingesti', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('sumber_id')->constrained('sumber_data');
            $t->timestamp('dimulai_pada')->nullable(); $t->timestamp('selesai_pada')->nullable(); $t->string('status',30)->default('antri');
            $t->integer('jumlah_ditemukan')->default(0); $t->integer('jumlah_diproses')->default(0); $t->integer('jumlah_gagal')->default(0);
            $t->text('pesan_gagal')->nullable(); $t->timestamps();
        });
        Schema::create('data_mentah', function(Blueprint $t){
            $t->bigIncrements('id'); $t->foreignUuid('sumber_id')->constrained('sumber_data'); $t->jsonb('payload');
            $t->timestamp('dikumpulkan_pada'); $t->string('hash',64); $t->boolean('diproses')->default(false); $t->timestamps();
            $t->unique(['sumber_id','hash']);
        });
        Schema::create('stok', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->uuid('gudang_id')->nullable(); $t->foreignUuid('varian_produk_id')->constrained('varian_produk');
            $t->decimal('jumlah',15,3)->default(0); $t->decimal('jumlah_dipesan',15,3)->default(0);
            $t->decimal('jumlah_tersedia',15,3)->default(0); $t->timestamp('diperbarui_pada')->useCurrent();
        });
        Schema::create('gudang', function(Blueprint $t){
            $t->uuid('id')->primary(); $t->foreignUuid('organisasi_id')->constrained('organisasi');
            $t->string('nama'); $t->text('alamat')->nullable(); $t->string('kota')->nullable(); $t->string('provinsi')->nullable();
            $t->decimal('lintang',10,7)->nullable(); $t->decimal('bujur',10,7)->nullable(); $t->timestamps();
        });
        Schema::create('permintaan_harian', function(Blueprint $t){
            $t->bigIncrements('id'); $t->foreignUuid('organisasi_id')->constrained('organisasi');
            $t->foreignUuid('varian_produk_id')->constrained('varian_produk'); $t->date('tanggal');
            $t->decimal('jumlah',15,3); $t->string('satuan',30); $t->timestamps();
            $t->unique(['organisasi_id','varian_produk_id','tanggal']);
        });
    }

    public function down(): void {
        foreach (['permintaan_harian','gudang','stok','data_mentah','pekerjaan_ingesti','sumber_data','log_audit','rekomendasi','prediksi','pesanan_pembelian','penawaran_item','penawaran','rfq_item','rfq','supplier_produk','observasi_harga','sumber_harga','supplier','alias_produk','varian_produk','produk','kategori','organisasi'] as $t) Schema::dropIfExists($t);
    }
};
