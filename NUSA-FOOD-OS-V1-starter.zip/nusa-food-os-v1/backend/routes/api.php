<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\KesehatanController;
use App\Http\Controllers\Api\V1\ProdukController;
use App\Http\Controllers\Api\V1\SupplierController;
use App\Http\Controllers\Api\V1\PengadaanController;
use App\Http\Controllers\Api\V1\IntelijenController;

Route::prefix('v1')->group(function () {
    Route::get('/kesehatan', [KesehatanController::class, 'index']);

    Route::get('/produk', [ProdukController::class, 'index']);
    Route::get('/produk/{produk}', [ProdukController::class, 'show']);

    Route::get('/supplier', [SupplierController::class, 'index']);
    Route::get('/supplier/{supplier}', [SupplierController::class, 'show']);

    Route::get('/intelijen/harga', [IntelijenController::class, 'harga']);
    Route::get('/intelijen/rekomendasi', [IntelijenController::class, 'rekomendasi']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/pengadaan/rfq', [PengadaanController::class, 'buatRfq']);
        Route::get('/pengadaan/rfq', [PengadaanController::class, 'daftarRfq']);
    });
});
