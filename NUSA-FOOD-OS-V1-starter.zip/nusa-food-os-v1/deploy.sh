#!/usr/bin/env bash
set -euo pipefail

test -f .env || cp .env.example .env
echo "Pastikan .env sudah berisi password produksi."
docker compose up -d --build
docker compose exec backend php artisan migrate --seed
echo "NUSA FOOD OS aktif. Periksa: /api/v1/kesehatan"
