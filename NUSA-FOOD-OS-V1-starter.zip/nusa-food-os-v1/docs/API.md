# API NUSA FOOD OS V1

Base URL: `/api/v1`

## Kesehatan
GET `/kesehatan`

## Produk
GET `/produk?q=beras`
GET `/produk/{id}`

## Supplier
GET `/supplier`
GET `/supplier/{id}`

## Intelijen
GET `/intelijen/harga?kota=Ternate`
GET `/intelijen/rekomendasi`

## Pengadaan
POST `/pengadaan/rfq`
GET `/pengadaan/rfq`

### Payload RFQ
```json
{
  "tanggal_dibutuhkan": "2026-09-15",
  "lokasi_pengiriman": "Ternate",
  "catatan": "Pengadaan bahan baku mingguan"
}
```

## Endpoint target V1.1
- POST /auth/login
- POST /auth/logout
- POST /auth/register
- POST /rfq/{id}/terbitkan
- POST /rfq/{id}/penawaran
- POST /penawaran/{id}/terima
- POST /purchase-order
- GET /intelijen/prediksi
- GET /intelijen/supplier
- POST /ingesti/csv
