# Arsitektur NUSA FOOD OS V1

## Modul
1. Identitas & organisasi
2. Katalog produk
3. Supplier
4. Gudang & stok
5. Harga
6. RFQ
7. Penawaran
8. Purchase Order
9. Data ingestion
10. Intelijen
11. Audit
12. Monitoring

## Alur
Buyer -> RFQ -> Supplier -> Penawaran -> Perbandingan landed cost -> PO -> Pengiriman -> Penerimaan -> data transaksi -> intelijen.

## Mesin intelijen
- V1 awal: baseline statistik/regresi.
- Tahap berikut: XGBoost untuk harga dan permintaan.
- LLM hanya untuk penjelasan/reasoning dan antarmuka, bukan sumber kebenaran angka.
- Semua prediksi menyimpan versi model dan confidence.

## Sumber data
Prioritas:
1. data transaksi internal
2. feed supplier
3. CSV/Excel supplier
4. API publik/resmi yang mengizinkan penggunaan
5. observasi manual
6. web ingestion yang legal dan sesuai ketentuan sumber

## Prinsip data
Data mentah tidak langsung menimpa data ter-normalisasi.
Pipeline:
RAW -> VALIDASI -> NORMALISASI -> DEDUPLIKASI -> ENTITY MATCHING -> QUALITY SCORE -> DATA UTAMA -> FEATURE -> MODEL.
