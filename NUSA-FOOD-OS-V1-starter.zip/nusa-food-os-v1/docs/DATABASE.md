# Database V1

Tabel inti:
- organisasi
- kategori
- produk
- varian_produk
- alias_produk
- supplier
- supplier_produk
- gudang
- stok
- sumber_harga
- observasi_harga
- sumber_data
- pekerjaan_ingesti
- data_mentah
- rfq
- rfq_item
- penawaran
- penawaran_item
- pesanan_pembelian
- permintaan_harian
- prediksi
- rekomendasi
- log_audit

Catatan:
- UUID digunakan untuk entitas bisnis.
- BIGINT digunakan untuk observasi/time-series dan log ber-volume tinggi.
- JSONB digunakan pada data mentah/audit.
- PostgreSQL + PostGIS disiapkan sejak awal untuk kebutuhan lokasi/rute.
