# Roadmap coding 90 hari

## Hari 1-14
Fondasi Docker, Laravel, PostgreSQL/PostGIS, Redis, autentikasi, organisasi, RBAC, CI/CD.

## Hari 15-30
Katalog, supplier, varian, stok, import CSV, audit log.

## Hari 31-45
RFQ, quotation, perbandingan harga, landed cost, PO.

## Hari 46-60
Price intelligence, sumber data, ingestion worker, normalisasi, deduplikasi.

## Hari 61-75
Demand/price forecast, supplier score, rekomendasi BUY NOW/WAIT/SWITCH/NEGOTIATE.

## Hari 76-90
Dashboard lengkap, notifikasi, observability, security hardening, backup, load test, deployment production.

## Definition of Done V1
- buyer dapat membuat RFQ
- supplier dapat memberi penawaran
- buyer dapat membandingkan total landed cost
- PO dapat dibuat
- histori harga tersimpan
- rekomendasi dapat dijelaskan
- audit log aktif
- API terdokumentasi
- queue/scheduler aktif
- database dapat dibackup dan dipulihkan
