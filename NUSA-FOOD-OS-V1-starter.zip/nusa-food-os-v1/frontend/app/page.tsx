export default function Beranda() {
  return (
    <main style={{fontFamily:"Arial",padding:40,maxWidth:1200,margin:"auto"}}>
      <h1>NUSA FOOD OS</h1>
      <p>Sistem Intelijen Pengadaan dan Rantai Pasok Pangan</p>
      <section style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16,marginTop:30}}>
        {[
          ["Pengadaan","Rp0"],
          ["Penghematan","Rp0"],
          ["RFQ Aktif","0"],
          ["Supplier","0"]
        ].map(([label,value]) => (
          <div key={label} style={{border:"1px solid #ddd",borderRadius:12,padding:20}}>
            <small>{label}</small><h2>{value}</h2>
          </div>
        ))}
      </section>
      <section style={{marginTop:40,border:"1px solid #ddd",borderRadius:12,padding:20}}>
        <h2>Intelijen Harga</h2>
        <p>Hubungkan sumber data harga untuk mulai menghasilkan tren, prediksi, dan rekomendasi pembelian.</p>
      </section>
    </main>
  );
}
