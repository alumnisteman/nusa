from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List
import numpy as np

app = FastAPI(title="NUSA Food Intelligence Engine", version="1.0.0")

class TitikHarga(BaseModel):
    tanggal: str
    harga: float = Field(gt=0)

class PermintaanPrediksi(BaseModel):
    wilayah: str
    produk: str
    data: List[TitikHarga]
    horizon_hari: int = Field(default=7, ge=1, le=90)

@app.get("/kesehatan")
def kesehatan():
    return {"status": "sehat", "layanan": "mesin intelijen NUSA", "versi": "1.0.0"}

@app.post("/v1/prediksi/harga")
def prediksi_harga(req: PermintaanPrediksi):
    harga = np.array([x.harga for x in req.data], dtype=float)
    if len(harga) < 2:
        nilai = float(harga[-1]) if len(harga) else 0
        kepercayaan = 0.25
    else:
        # Baseline V1: regresi linear sederhana.
        x = np.arange(len(harga))
        slope, intercept = np.polyfit(x, harga, 1)
        nilai = float(intercept + slope * (len(harga) + req.horizon_hari - 1))
        kepercayaan = float(min(0.90, max(0.30, 1 - np.std(harga) / max(np.mean(harga), 1))))
    return {
        "wilayah": req.wilayah,
        "produk": req.produk,
        "horizon_hari": req.horizon_hari,
        "prediksi": round(max(nilai, 0), 2),
        "kepercayaan": round(kepercayaan, 4),
        "model": "baseline-regresi-linear-v1"
    }
